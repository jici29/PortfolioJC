async function loadXML() {
    const response = await fetch('/static/data.xml');
    const xmlText = await response.text();
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlText, "application/xml");

    // Home
    const home = xmlDoc.querySelector("home");
    document.getElementById("profile-photo").src = "/static/" + home.querySelector("profilephoto").textContent;
    document.getElementById("full-name").textContent = home.querySelector("fullname").textContent;
    document.getElementById("tagline").textContent = home.querySelector("tagline").textContent;
    document.getElementById("location").textContent = home.querySelector("location").textContent;

    const homeSocialLinks = document.getElementById("home-social-links");
    homeSocialLinks.innerHTML = "";
    home.querySelectorAll("socialmedia > link").forEach(link => {
        const a = document.createElement("a");
        a.href = link.getAttribute("url");
        a.target = "_blank";
        a.textContent = link.getAttribute("platform");
        homeSocialLinks.appendChild(a);
        homeSocialLinks.appendChild(document.createTextNode(" | "));
    });
    if (homeSocialLinks.lastChild) homeSocialLinks.removeChild(homeSocialLinks.lastChild); // Remove last separator

    // Portfolio Projects
    const projectsDiv = document.getElementById("projects");
    projectsDiv.innerHTML = "";
    xmlDoc.querySelectorAll("projects > project").forEach(project => {
        const div = document.createElement("div");
        div.className = "project";

        const title = document.createElement("h3");
        title.textContent = project.querySelector("title").textContent;
        div.appendChild(title);

        const desc = document.createElement("p");
        desc.textContent = project.querySelector("description").textContent;
        div.appendChild(desc);

        const tech = document.createElement("p");
        tech.innerHTML = "<strong>Technologies:</strong> " + project.querySelector("technologies").textContent;
        div.appendChild(tech);

        const link = document.createElement("p");
        const a = document.createElement("a");
        a.href = project.querySelector("link").textContent;
        a.target = "_blank";
        a.textContent = "GitHub Link";
        link.appendChild(a);
        div.appendChild(link);

        projectsDiv.appendChild(div);
    });

    // Skills & Talents
    const techSkillsUl = document.getElementById("technical-skills");
    techSkillsUl.innerHTML = "";
    xmlDoc.querySelectorAll("skills > technical > skill").forEach(skill => {
        const li = document.createElement("li");
        li.textContent = skill.textContent;
        techSkillsUl.appendChild(li);
    });

    const talentsUl = document.getElementById("talents");
    talentsUl.innerHTML = "";
    xmlDoc.querySelectorAll("skills > talents > talent").forEach(talent => {
        const li = document.createElement("li");
        li.textContent = talent.textContent;
        talentsUl.appendChild(li);
    });

    // Organizations
    const orgList = document.getElementById("organizations-list");
    orgList.innerHTML = "";
    xmlDoc.querySelectorAll("organizations > organization").forEach(org => {
        const li = document.createElement("li");
        li.textContent = org.querySelector("name").textContent + " - " + org.querySelector("role").textContent + " (" + org.querySelector("years").textContent + ")";
        orgList.appendChild(li);
    });

    // Services
    const servicesDiv = document.getElementById("services-list");
    servicesDiv.innerHTML = "";
    xmlDoc.querySelectorAll("services > service").forEach(service => {
        const div = document.createElement("div");
        div.className = "service";

        const h3 = document.createElement("h3");
        h3.textContent = service.querySelector("name").textContent;
        div.appendChild(h3);

        const p = document.createElement("p");
        p.textContent = service.querySelector("description").textContent;
        div.appendChild(p);

        servicesDiv.appendChild(div);
    });

    // Testimonials in Services section (first two)
    const testimonialsHomeDiv = document.getElementById("testimonials-home");
    testimonialsHomeDiv.innerHTML = "";
    const testimonials = xmlDoc.querySelectorAll("testimonials > testimonial");
    for (let i = 0; i < 2 && i < testimonials.length; i++) {
        const t = testimonials[i];
        const blockquote = document.createElement("blockquote");
        const p = document.createElement("p");
        p.textContent = '"' + t.querySelector("message").textContent + '"';
        blockquote.appendChild(p);
        const footer = document.createElement("footer");
        footer.textContent = "- " + t.querySelector("person").textContent + ", " + t.querySelector("relationship").textContent;
        blockquote.appendChild(footer);
        testimonialsHomeDiv.appendChild(blockquote);
    }

    // Testimonials section (all)
    const testimonialsListDiv = document.getElementById("testimonials-list");
    testimonialsListDiv.innerHTML = "";
    testimonials.forEach(t => {
        const blockquote = document.createElement("blockquote");
        const p = document.createElement("p");
        p.textContent = '"' + t.querySelector("message").textContent + '"';
        blockquote.appendChild(p);
        const footer = document.createElement("footer");
        footer.textContent = "- " + t.querySelector("person").textContent + ", " + t.querySelector("relationship").textContent;
        blockquote.appendChild(footer);
        testimonialsListDiv.appendChild(blockquote);
    });

    // Contact
    const contact = xmlDoc.querySelector("contact");
    document.getElementById("contact-email").textContent = contact.querySelector("email").textContent;
    document.getElementById("contact-phone").textContent = contact.querySelector("phone").textContent;

    const contactSocialLinks = document.getElementById("contact-social-links");
    contactSocialLinks.innerHTML = "";
    contact.querySelectorAll("socialmedia > link").forEach(link => {
        const a = document.createElement("a");
        a.href = link.getAttribute("url");
        a.target = "_blank";
        a.textContent = link.getAttribute("platform");
        contactSocialLinks.appendChild(a);
        contactSocialLinks.appendChild(document.createTextNode(" | "));
    });
    if (contactSocialLinks.lastChild) contactSocialLinks.removeChild(contactSocialLinks.lastChild); // Remove last separator
}

window.onload = loadXML;

// Burger menu toggle
const burgerMenu = document.getElementById('burger-menu');
const navLinks = document.getElementById('nav-links');

burgerMenu.addEventListener('click', () => {
    navLinks.classList.toggle('nav-active');
    burgerMenu.classList.toggle('toggle');
});

// Accessibility: toggle menu on Enter or Space key
burgerMenu.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        navLinks.classList.toggle('nav-active');
        burgerMenu.classList.toggle('toggle');
    }
});
